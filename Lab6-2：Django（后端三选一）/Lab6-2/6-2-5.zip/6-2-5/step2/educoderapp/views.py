from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

    # ********** Begin ********** #
def hello(request):
    return HttpResponse("Hello Educoder")

    # ********** End ********** #